KL1 — Web‑only (No Keys)
================================

This folder is a **static website** you can put online in under a minute. It requires **no API keys** and runs fully in the browser using the Web Speech API.

Host it with one of these zero‑setup options:
- **Netlify Drop:** https://app.netlify.com/drop  → drag the `site` folder → you get a link.
- **Cloudflare Pages (Direct Upload):** https://dash.cloudflare.com/ → Pages → Create → Direct Upload → add `site`.
- **GitHub Pages:** Create a repo → upload `site` → Settings → Pages → `main`/`root`.

After upload, your link will look like `https://your-site-name.netlify.app` (or similar).

You can also just open `site/index.html` locally by double‑clicking it (voice features work best in Chrome).

When you later deploy the full KL1 API, put its URL in **Settings** inside the web app so it can call it.
